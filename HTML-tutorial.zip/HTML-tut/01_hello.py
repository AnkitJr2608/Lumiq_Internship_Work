print("hello world")
print(3 % 4)
a = 5
print(type(a))
s = str(a)
print(s)
#c = int(input("enter number"))
# print(c)
s1 = "harry's"
s2 = 'harry"s'
s3 = '''harry"s and harry's'''
print(s1, " ", s2, " ", s3)
print(s1[2])
print(s1[2:])
# print(s1[2:0])
print(s1[2:-1])
print(s1[-1])
print(s1[:4])
print(s1[:7])
# print(s1[4:-4])
