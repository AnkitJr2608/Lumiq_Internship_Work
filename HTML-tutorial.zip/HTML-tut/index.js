function load_intro()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/intro.html" style="width:100%;height:1200px" ></object>'; 
}
function load_basicTags()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/basic.html" style="width:100%;height:1200px" ></object>'; 
}
function load_elements()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/elements.html" style="width:100%;height:1200px" ></object>'; 
}
function load_formatting()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/formatting.html" style="width:100%;height:1200px" ></object>'; 
}
function load_phrase()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/phrase.html" style="width:100%;height:1200px" ></object>'; 
}
function load_meta()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/meta.html" style="width:100%;height:1200px" ></object>'; 
}

function load_images()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/images.html" style="width:100%;height:1200px" ></object>'; 
}

function load_comments()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/comments.html" style="width:100%;height:1200px" ></object>'; 
}
function load_tables()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/tables.html" style="width:100%;height:1200px" ></object>'; 
}
function load_lists()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/lists.html" style="width:100%;height:1200px" ></object>'; 
}
function load_text_links()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/text_links.html" style="width:100%;height:1200px" ></object>'; 
}
function load_image_links()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/image_links.html" style="width:100%;height:1200px" ></object>'; 
}
function load_email_links()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/email_links.html" style="width:100%;height:1200px" ></object>'; 
}
function load_frames()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/frames.html" style="width:100%;height:1200px" ></object>'; 
}
function load_iframes()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/iframes.html" style="width:100%;height:1200px" ></object>'; 
}
function load_blocks()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/blocks.html" style="width:100%;height:1200px" ></object>'; 
}
function load_forms()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/forms.html" style="width:100%;height:1200px" ></object>'; 
}
function load_embed()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/embed.html" style="width:100%;height:1200px" ></object>'; 
}
function load_header()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/header.html" style="width:100%;height:1200px" ></object>'; 
}
function load_stylesheet()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/stylesheet.html" style="width:100%;height:1200px" ></object>'; 
}
function load_javascript()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/javascript.html" style="width:100%;height:1200px" ></object>'; 
}
function load_layouts()
{
    document.getElementById("information").innerHTML='<object type="text/html" data="Pages/Main-Pages/layouts.html" style="width:100%;height:1200px" ></object>'; 
}





